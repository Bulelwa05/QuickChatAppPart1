/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchatapp1;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author Student
 */
public class QuickChatApp1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // The user is asked to input first name
        System.out.println("Please enter your first name ");
        String firstName = scanner.nextLine();
        
        //The user is asked to input last name
        System.out.println("Please enter your last name");
        String lastName = scanner.nextLine();
        
        //The user is asked to input cell number
        System.out.print("Please enter cell phone number with +27: ");
        String phoneNumber = scanner.nextLine();
                
        //The user is asked to input username
        System.out.print("Please enter username: ");
        String username = scanner.nextLine();

        //The user is asked to input password
        System.out.print("Please enter password: ");
        String password = scanner.nextLine();

        // A registration object is created to ensure that the details entered are correct
        Registration reg = new Registration(username, password, phoneNumber);
        System.out.println(reg.validateUsername());
        System.out.println(reg.validatePassword());
        System.out.println(reg.validatePhoneNumber());

        // These messages get output if the user entered registration details correctly
        if (reg.validateUsername().equals("Username successfully captured.") &&
            reg.validatePassword().equals("Password successfully captured.") &&
            reg.validatePhoneNumber().equals("Cell phone number successfully added.")) {
            System.out.println("Registration successful.");

    //This is login input
    System.out.print("Please enter your username: ");
    String loginUsername = scanner.nextLine();

    System.out.print("Please enter your password: ");
    String loginPassword = scanner.nextLine();

    //A login object
    Login login = new Login(reg.getUsername(), reg.getPassword());

    // Login message
    String loginMessage = login.returnLoginStatus(
            loginUsername, loginPassword, firstName, lastName);

    System.out.println(loginMessage);

    //The code continues if the login from the useer is successful
    if (loginMessage.contains("great to see you again")) {

        System.out.println("Welcome to QuickChat.");

        //Asks how many messages user wants to send
        System.out.println("How many messages would you like to send?");
        int messageLimit = scanner.nextInt();
        scanner.nextLine();

        //ArrayList is created to store messages
        ArrayList<Message> messages = new ArrayList<>();

        //A loop is created for sending messages/recipient
        for (int i = 0; i < messageLimit; i++) {
            System.out.println("Enter recipient number:");
            String recipient = scanner.nextLine();

            System.out.println("Enter message:");
            String msg = scanner.nextLine();

            Message message = new Message(recipient, msg);
            //The Message option menu is created
            System.out.println("Choose an option:");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message");

            int choice = scanner.nextInt();
            scanner.nextLine();
            System.out.println(message.sendMessage(choice));

            //If statement is created to store if the message is not discarded
            if (choice != 2) {
                messages.add(message);
                System.out.println(message.printMessageDetails());
            }
        }

        //Total messages
        System.out.println("Total messages processed: " + messages.size());
    }
     } else {
    System.out.println("Registration failed. Please try again.");
            }
}
}

    

    

